package hello.master;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity
{
    //public boolean run;
    @Override

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

     //   while(true)
        {  // run=true;
            startService(new Intent(this, MyService.class));

        }

    }



    public void startService(View view)
    {

        startService(new Intent(this, MyService.class));
    }

    // Method to stop the service
    public void stopService(View view)
    {
        stopService(new Intent(getBaseContext(), MyService.class));
       // run=false;
       // Intent(getBaseContext().stopService(MyService.class);
    }




}
