package hello.master;

/**
 * Created by root on 27/1/17.
 */
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.util.ArrayList;

import static java.sql.Types.NULL;

/**
 * Created by TutorialsPoint7 on 8/23/2016.
 */

public class MyService extends Service {

    private ArrayList<String> mDeviceList = new ArrayList<String>();
    private BluetoothAdapter mBluetoothAdapter;
    AudioManager myAudioManager;
    boolean k;
    @Nullable


    @Override
    public IBinder onBind(Intent intent) {

      //  Toast.makeText(this,"Master running", Toast.LENGTH_LONG).show();



        return null;
    }

    @Override
    public void onCreate()
    {
        Toast.makeText(this,"Master started", Toast.LENGTH_LONG).show();
        k=true;
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {


        //Toast.makeText(this, "Master Started", Toast.LENGTH_LONG).show();

        new Thread(new Runnable() {
            //  MainActivity o1=new MainActivity();
            @Override

            public void run() {


                //Your logic that service will perform will be placed here


                //In this example we are just looping and waits for 1000 milliseconds in each loop.
               while(k)
                {


                    try
                    {


                        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                        if (!mBluetoothAdapter.isEnabled())
                        {
                            mBluetoothAdapter.enable();;

                        }
                        mBluetoothAdapter.startDiscovery();

                        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                        registerReceiver(mReceiver, filter);


                        Thread.sleep(100);

                    } catch (Exception e)
                    {

                    }

                }


            }
        }).start();





        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        mBluetoothAdapter.disable();
        myAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        myAudioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        k=false;
      //  stopService();
        Toast.makeText(this, "Master Stopped", Toast.LENGTH_LONG).show();
    }


    private final BroadcastReceiver mReceiver = new BroadcastReceiver()
    {
        public void onReceive(Context context, Intent intent)
        {


            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {

                BluetoothDevice device = intent
                        .getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                if(device.getName().equals("g-link"))

                {  // AudioManager myAudioManager;
                    myAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
                    myAudioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);


                }
                mDeviceList.add(device.getName());
                Log.i("BT", device.getName() + "\n" + device.getAddress());
             //   listView.setAdapter(new ArrayAdapter<String>(context,
                      //  android.R.layout.simple_list_item_1, mDeviceList));
            }
            int N=mDeviceList.size();

           /*

            for(int i=0;i<N;i++)
            {
                if(mDeviceList.get(i).equals("g-link"))

                {  // AudioManager myAudioManager;
                    myAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
                    myAudioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
                  //  Toast toast=Toast.makeText(getApplicationContext(),"changing mode",Toast.LENGTH_SHORT);
                   // toast.setMargin(50,50);

                }


            }

            */


        }


    };







}